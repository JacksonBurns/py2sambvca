from py2sambvca import py2sambvca

if __name__ == "__main__":
    main()