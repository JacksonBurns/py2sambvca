# py2sambvca
 Simple thin client to interface python scripts with SambVca catalytic pocket fortran calculator.
